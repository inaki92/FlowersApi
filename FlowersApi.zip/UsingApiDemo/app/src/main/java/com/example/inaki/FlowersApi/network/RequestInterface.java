package com.example.inaki.FlowersApi.network;

import com.example.inaki.FlowersApi.data.FlowersModel;

import java.util.List;

import retrofit2.http.GET;
import io.reactivex.Observable;

public interface RequestInterface {
    @GET("feeds/flowers.json")
    Observable<List<FlowersModel>>register();

}
