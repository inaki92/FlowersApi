package com.example.inaki.flowersmvp.network;

public class API_Request {

    public static final String FLOWERS_BASE_URL = "http://services.hanselandpetal.com/";
    public static final String API_FLOWERS_LIST = "feeds/flowers.json";

}
